function gerarNumero(min, max) {
    if (min > max) {
        [max, min] = [min, max] }
    return new Promise(resolve => {
        const fator = max - min + 1
        const aleatoria = parseInt(Math.random() * fator) + min
        resolve(aleatoria)
    })
}
gerarNumero(1, 60)
    .then(num => num * 5)
    .then(numX5 => console.log(`O multiplicado por 5 é ${numX5}.`))