// não aceita valores repetidos  //não é indexada

const times = new Set()
times.add('Inter')
times.add('Gremio').add('Flamengo').add('São Paulo').add('Palmeiras')

console.log(times)
console.log(times.size)
console.log(times.has('Gremio'))
times.delete('Palmeiras')

const nomes = ['Maciel', 'Michel', 'Júlia']
const nomeSet = new Set(nomes)
console.log(nomeSet)