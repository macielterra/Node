/*const node1 = require('../../node1')
const node2 = require('../../node2')
console.log(node1, node2)*/

const http = require('http')
http.createServer((req, res) => {
    res.write('Bom dia!')
    res.end()
}).listen(8080)