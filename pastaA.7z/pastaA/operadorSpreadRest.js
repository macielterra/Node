// Usar o Spread como Objeto
const funcionario = { nome: 'Maciel', idade: 39 }
const clone = { ativo: true, ...funcionario }
console.log(clone)

// Usar Spread como Array
const grupoA = ['joão', 'pedro', 'gloria']
const grupoFinal = ['maria', ...grupoA, 'rafaela']
console.log(grupoFinal)