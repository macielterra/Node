function esperarPor(tempo = 5000) {
    return new Promise(function(resolve) {
        setTimeout(function() {
            console.log('executando Promise...')
            resolve('Bahhhh')
        }, tempo)
    })
}
esperarPor(3000)
    .then(texto => console.log(texto))