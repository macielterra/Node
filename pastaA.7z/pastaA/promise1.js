const vetor = array => array[0]
const primeiraLetra = string => string[0]
const letraMin = letra => letra.toLowerCase()

let p = new Promise(function(cumprirPromessa) {
        cumprirPromessa(['Ana', 'Maria', 'Pedro', 'João'])
    })
    .then(vetor)
    .then(primeiraLetra)
    .then(letraMin)
    .then(console.log)